# NB Addon

A Meteor Client addon for Minecraft 1.21.11.

## Setup
1. Install Meteor Client
2. Drop the jar into your mods folder
