package com.nb.nbaddon.modules.main;
import com.nb.nbaddon.NBAddon;


import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class PaperRig extends Module {
    private final SettingGroup sgRigging = settings.createGroup("Rigging");

    public boolean sendToggleMsg() { return false; }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> riggingEnabled = sgRigging.add(new BoolSetting.Builder()
        .name("rigging-enabled")
        .description("Enable rigging to force selected items to win.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Item> dispenser1Item = sgRigging.add(new ItemSetting.Builder()
        .name("dispenser-1-item")
        .description("Item for dispenser 1.")
        .defaultValue(Items.DIAMOND)
        .build()
    );

    private final Setting<Item> dispenser2Item = sgRigging.add(new ItemSetting.Builder()
        .name("dispenser-2-item")
        .description("Item for dispenser 2.")
        .defaultValue(Items.EMERALD)
        .build()
    );

    private final Setting<Integer> winningItem = sgRigging.add(new IntSetting.Builder()
        .name("winning-item")
        .description("Which item should win (1 = dispenser-1-item, 2 = dispenser-2-item).")
        .defaultValue(1)
        .min(1)
        .max(2)
        .build()
    );

    private final Setting<String> switchWinnerKey = sgGeneral.add(new StringSetting.Builder()
        .name("switch-winner-key")
        .description("Key to switch winner (e.g. H).")
        .defaultValue("H")
        .build()
    );

    private final Setting<String> toggleRiggingKey = sgGeneral.add(new StringSetting.Builder()
        .name("toggle-rigging-key")
        .description("Key to toggle rigging on/off (e.g. G).")
        .defaultValue("G")
        .build()
    );

    private boolean toggleRiggingKeyPressed = false;
    private boolean switchWinnerKeyPressed = false;

    private BlockPos dispenser1 = null;
    private BlockPos dispenser2 = null;

    private int state = 0;

    private int baselineCount1 = 0;
    private int baselineCount2 = 0;

    private Integer lockedNumber = null;
    private Item lockedItem = null;

    private String statusMessage = "Searching for dispensers...";

    private static PaperRig instance;

    public PaperRig() {
        super(NBAddon.CATEGORY, "paper-rig", "Rig paper gambling to force selected item to win.");
        chatFeedback = false;
        instance = this;
    }

    public static PaperRig get() { return instance; }
    public boolean isRiggingEnabled() { return riggingEnabled.get(); }

    public String getRiggedName(ItemStack stack, String originalName) {
        if (stack == null) return null;
        if (lockedItem != null && lockedNumber != null && stack.getItem() == lockedItem) {
            return replaceNumberInText(originalName, lockedNumber);
        }
        return null;
    }

    /**
     * Takes the existing item name (e.g. "Host 3") and replaces
     * only the number part with newNumber (e.g. "Host 7").
     * If no number found, appends the number.
     */
    private String replaceNumberInText(String original, int newNumber) {
        if (original == null || original.isEmpty()) return String.valueOf(newNumber);
        StringBuilder result = new StringBuilder();
        int i = 0;
        boolean replaced = false;
        while (i < original.length()) {
            if (!replaced && Character.isDigit(original.charAt(i))) {
                while (i < original.length() && Character.isDigit(original.charAt(i))) i++;
                result.append(newNumber);
                replaced = true;
            } else {
                result.append(original.charAt(i));
                i++;
            }
        }
        return result.toString();
    }

    @Override
    public void onActivate() {
        dispenser1 = null;
        dispenser2 = null;
        state = 0;
        lockedNumber = null;
        lockedItem = null;
        baselineCount1 = 0;
        baselineCount2 = 0;
        statusMessage = "Searching for dispensers...";
    }

    @Override
    public void onDeactivate() {
        dispenser1 = null;
        dispenser2 = null;
        lockedNumber = null;
        lockedItem = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        int toggleCode = getKeyCodeByName(toggleRiggingKey.get());
        if (toggleCode != -1) {
            boolean p = GLFW.glfwGetKey(mc.getWindow().getHandle(), toggleCode) == GLFW.GLFW_PRESS;
            if (p && !toggleRiggingKeyPressed) riggingEnabled.set(!riggingEnabled.get());
            toggleRiggingKeyPressed = p;
        }
        int switchCode = getKeyCodeByName(switchWinnerKey.get());
        if (switchCode != -1) {
            boolean p = GLFW.glfwGetKey(mc.getWindow().getHandle(), switchCode) == GLFW.GLFW_PRESS;
            if (p && !switchWinnerKeyPressed) winningItem.set(winningItem.get() == 1 ? 2 : 1);
            switchWinnerKeyPressed = p;
        }

        if (dispenser1 == null || dispenser2 == null) {
            findDispensers();
            if (dispenser1 == null || dispenser2 == null) return;
            baselineCount1 = countItemInInventory(dispenser1Item.get());
            baselineCount2 = countItemInInventory(dispenser2Item.get());
            state = 0;
            statusMessage = "Ready — pull the lever!";
            return;
        }

        int current1 = countItemInInventory(dispenser1Item.get());
        int current2 = countItemInInventory(dispenser2Item.get());

        if (state == 1) {
            int winnerCurrent  = (lockedItem == dispenser1Item.get()) ? current1 : current2;
            int winnerBaseline = (lockedItem == dispenser1Item.get()) ? baselineCount1 : baselineCount2;

            if (winnerCurrent <= winnerBaseline) {
                lockedNumber = null;
                lockedItem = null;
                state = 2;
                statusMessage = "Waiting for items to clear...";
            }
            return;
        }

        if (state == 2) {
            if (current1 <= baselineCount1 && current2 <= baselineCount2) {
                baselineCount1 = current1;
                baselineCount2 = current2;
                state = 0;
                statusMessage = "Ready — pull the lever!";
            }
            return;
        }

        boolean new1arrived = current1 > baselineCount1;
        boolean new2arrived = current2 > baselineCount2;

        if (!new1arrived || !new2arrived) return;

        ItemStack item1 = getItemFromInventory(dispenser1Item.get());
        ItemStack item2 = getItemFromInventory(dispenser2Item.get());

        int number1 = extractNumber(item1);
        int number2 = extractNumber(item2);

        if (riggingEnabled.get()) {
            if (winningItem.get() == 1) {
                int rigged = (number1 >= number2) ? number1 : pickOne(number2, 9);
                lockedItem = dispenser1Item.get();
                lockedNumber = rigged;
                statusMessage = "D1: " + rigged + " vs D2: " + number2;
            } else {
                int rigged = (number2 >= number1) ? number2 : pickOne(number1, 9);
                lockedItem = dispenser2Item.get();
                lockedNumber = rigged;
                statusMessage = "D1: " + number1 + " vs D2: " + rigged;
            }
        } else {
            lockedItem = null;
            lockedNumber = null;
            int winner = number1 > number2 ? 1 : (number2 > number1 ? 2 : 0);
            statusMessage = "D" + winner + " wins (" + number1 + " vs " + number2 + ")";
        }

        state = 1;
    }


    private int countItemInInventory(Item item) {
        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.getItem() == item) count += s.getCount();
        }
        return count;
    }

    private ItemStack getItemFromInventory(Item item) {
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.getItem() == item) return s;
        }
        return null;
    }

    private void findDispensers() {
        List<BlockPos> found = new ArrayList<>();
        BlockPos p = mc.player.getBlockPos();
        int r = 5;
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = p.add(x, y, z);
                    if (mc.world.getBlockState(pos).getBlock() == Blocks.DISPENSER)
                        found.add(pos);
                }
        if (found.size() >= 2) {
            dispenser1 = found.get(0);
            dispenser2 = found.get(1);
        } else {
            dispenser1 = null;
            dispenser2 = null;
            statusMessage = "Need 2 dispensers nearby";
        }
    }

    private int extractNumber(ItemStack stack) {
        if (stack == null) return 1;
        try {
            String name = stack.getName().getString();
            for (int i = 0; i < name.length(); i++) {
                if (Character.isDigit(name.charAt(i))) {
                    int num = 0;
                    while (i < name.length() && Character.isDigit(name.charAt(i)))
                        num = num * 10 + (name.charAt(i++) - '0');
                    return num;
                }
            }
        } catch (Exception e) { /* ignore */ }
        return 1;
    }

    private int pickOne(int min, int max) {
        if (min >= max) return min;
        return min + mc.world.random.nextInt(max - min + 1);
    }

    private int getKeyCodeByName(String keyName) {
        if (keyName == null || keyName.isEmpty()) return -1;
        switch (keyName.toUpperCase()) {
            case "A": return GLFW.GLFW_KEY_A; case "B": return GLFW.GLFW_KEY_B;
            case "C": return GLFW.GLFW_KEY_C; case "D": return GLFW.GLFW_KEY_D;
            case "E": return GLFW.GLFW_KEY_E; case "F": return GLFW.GLFW_KEY_F;
            case "G": return GLFW.GLFW_KEY_G; case "H": return GLFW.GLFW_KEY_H;
            case "I": return GLFW.GLFW_KEY_I; case "J": return GLFW.GLFW_KEY_J;
            case "K": return GLFW.GLFW_KEY_K; case "L": return GLFW.GLFW_KEY_L;
            case "M": return GLFW.GLFW_KEY_M; case "N": return GLFW.GLFW_KEY_N;
            case "O": return GLFW.GLFW_KEY_O; case "P": return GLFW.GLFW_KEY_P;
            case "Q": return GLFW.GLFW_KEY_Q; case "R": return GLFW.GLFW_KEY_R;
            case "S": return GLFW.GLFW_KEY_S; case "T": return GLFW.GLFW_KEY_T;
            case "U": return GLFW.GLFW_KEY_U; case "V": return GLFW.GLFW_KEY_V;
            case "W": return GLFW.GLFW_KEY_W; case "X": return GLFW.GLFW_KEY_X;
            case "Y": return GLFW.GLFW_KEY_Y; case "Z": return GLFW.GLFW_KEY_Z;
            case "0": return GLFW.GLFW_KEY_0; case "1": return GLFW.GLFW_KEY_1;
            case "2": return GLFW.GLFW_KEY_2; case "3": return GLFW.GLFW_KEY_3;
            case "4": return GLFW.GLFW_KEY_4; case "5": return GLFW.GLFW_KEY_5;
            case "6": return GLFW.GLFW_KEY_6; case "7": return GLFW.GLFW_KEY_7;
            case "8": return GLFW.GLFW_KEY_8; case "9": return GLFW.GLFW_KEY_9;
            case "SPACE": return GLFW.GLFW_KEY_SPACE;
            case "ENTER": return GLFW.GLFW_KEY_ENTER;
            case "ESC": return GLFW.GLFW_KEY_ESCAPE;
            case "TAB": return GLFW.GLFW_KEY_TAB;
            case "SHIFT": return GLFW.GLFW_KEY_LEFT_SHIFT;
            case "CTRL": return GLFW.GLFW_KEY_LEFT_CONTROL;
            case "ALT": return GLFW.GLFW_KEY_LEFT_ALT;
            default: return -1;
        }
    }
}
