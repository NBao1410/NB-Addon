package com.nb.nbaddon;

import com.nb.nbaddon.modules.esp.*;
import com.nb.nbaddon.modules.main.*;
import com.nb.nbaddon.modules.pvp.*;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;

public class NBAddon extends MeteorAddon {

    public static final Category CATEGORY = new Category("NB Addon", new ItemStack(Items.CAKE));
    public static final Category esp = new Category("NB Addon ESP", new ItemStack(Items.VINE));
    public static final Category pvp = new Category("NB Addon PVP", new ItemStack(Items.DIAMOND_SWORD));

    public static int MyScreenVERSION = 16;

    @Override
    public void onInitialize() {
        // NB Addon (main)
        Modules.get().add(new PaperRig());
        Modules.get().add(new AdminList());
        Modules.get().add(new AHSell());
        Modules.get().add(new AHSniper());
        Modules.get().add(new AutoSell());
        Modules.get().add(new AutoTreeFarmer());
        Modules.get().add(new CoordSnapper());
        Modules.get().add(new HideScoreboard());
        Modules.get().add(new PlayerDetection());
        Modules.get().add(new SpawnerDropper());
        Modules.get().add(new SpawnerOrder());
        Modules.get().add(new SpawnerProtect());
        Modules.get().add(new ChestAndShulkerStealer());
        Modules.get().add(new TabDetector());
        Modules.get().add(new TpaAllMacro());
        Modules.get().add(new TpaMacro());

        // NB Addon PVP (giữ tất cả trừ WindPearlMacro, SwordPlaceObsidian)
        Modules.get().add(new TriggerBot());
        Modules.get().add(new AimAssist());
        Modules.get().add(new AnchorMacro());
        Modules.get().add(new AntiTrap());
        Modules.get().add(new AutoDoubleHand());
        Modules.get().add(new AutoInvTotem());
        Modules.get().add(new BreachSwap());
        Modules.get().add(new CrystalMacro());
        Modules.get().add(new DoubleAnchorMacro());
        Modules.get().add(new HoverTotem());
        Modules.get().add(new KeyPearl());
        Modules.get().add(new ShieldBreaker());

        // NB Addon ESP (xóa các ESP không cần)
        Modules.get().add(new AdvancedStashFinder());
        Modules.get().add(new BedrockVoidESP());
        Modules.get().add(new BlockNotifier());
        Modules.get().add(new ChunkFinder());
        Modules.get().add(new ClusterFinder());
        Modules.get().add(new HoleTunnelStairsESP());
        Modules.get().add(new InvisESP());
        Modules.get().add(new KelpESP());
        Modules.get().add(new LamaESP());
        Modules.get().add(new LightESP());
        Modules.get().add(new RegionMap());
        Modules.get().add(new RotatedDeepslateESP());
        Modules.get().add(new SpawnerNotifier());
        Modules.get().add(new VillagerESP());
    }

    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        MyScreen.checkVersionOnServerJoin();
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        MyScreen.resetSessionCheck();
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
        Modules.registerCategory(esp);
        Modules.registerCategory(pvp);
    }

    @Override
    public String getPackage() {
        return "com.nb.nbaddon";
    }
}
