package com.nb.nbaddon.modules.pvp;
import com.nb.nbaddon.NBAddon;


import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import java.util.Random;

public class TriggerBot extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public boolean sendToggleMsg() {
        return false;
    }


    private final Setting<Boolean> players = sgGeneral.add(new BoolSetting.Builder()
        .name("players")
        .description("Attack players.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> mobs = sgGeneral.add(new BoolSetting.Builder()
        .name("mobs")
        .description("Attack hostile mobs.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> distance = sgGeneral.add(new DoubleSetting.Builder()
        .name("distance")
        .description("Maximum attack distance.")
        .defaultValue(4.5)
        .min(1.0)
        .max(6.0)
        .sliderMax(6.0)
        .build()
    );

    private final Setting<Boolean> onlyWithWeapon = sgGeneral.add(new BoolSetting.Builder()
        .name("only-with-weapon")
        .description("Only attack when holding a weapon.")
        .defaultValue(false)
        .build()
    );

    private final Random random = new Random();
    private long lastAttackTime = 0;
    private int consecutiveHits = 0;
    private boolean shouldMiss = false;



    public TriggerBot() {
        super(NBAddon.pvp, "trigger-bot", "Automatically attacks entities when looking at them.");
    }


    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;
        if (mc.interactionManager.isBreakingBlock()) return;

        if (mc.player.getAttackCooldownProgress(0) < 1.0f) return;

        if (onlyWithWeapon.get() && !isHoldingWeapon()) return;

        Entity target = getTarget();
        if (target == null) {
            consecutiveHits = 0;
            return;
        }

        long currentTime = System.currentTimeMillis();
        long reactionDelay = (long)(100 + random.nextDouble() * 150);
        if (currentTime - lastAttackTime < reactionDelay) return;

        double missChance = Math.min(0.05 + consecutiveHits * 0.02, 0.25);
        if (random.nextDouble() < missChance) {
            shouldMiss = true;
            consecutiveHits = 0;
        }

        if (random.nextDouble() < 0.1) {
            return;
        }

        performAttack(target);
        lastAttackTime = currentTime;
        consecutiveHits++;
    }

    private void performAttack(Entity target) {
        if (shouldMiss) {
            float currentYaw = mc.player.getYaw();
            float currentPitch = mc.player.getPitch();

            float yawOffset = (random.nextFloat() - 0.5f) * 10f;
            float pitchOffset = (random.nextFloat() - 0.5f) * 10f;

            mc.player.setYaw(currentYaw + yawOffset);
            mc.player.setPitch(currentPitch + pitchOffset);

            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);

            mc.player.setYaw(currentYaw);
            mc.player.setPitch(currentPitch);

            shouldMiss = false;
        } else {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private Entity getTarget() {
        if (mc.crosshairTarget == null) return null;

        if (!(mc.crosshairTarget instanceof EntityHitResult)) return null;

        Entity entity = ((EntityHitResult) mc.crosshairTarget).getEntity();
        if (entity == null) return null;

        if (!(entity instanceof LivingEntity)) return null;
        if (entity == mc.player) return null;
        if (!entity.isAlive()) return null;

        LivingEntity livingEntity = (LivingEntity) entity;

        if (!shouldTarget(livingEntity)) return null;

        double distance = mc.player.distanceTo(entity);
        if (distance > this.distance.get()) return null;

        if (!mc.player.canSee(entity)) return null;

        return entity;
    }

    private boolean shouldTarget(LivingEntity entity) {
        if (entity instanceof PlayerEntity) {
            return players.get();
        } else if (isHostileMob(entity)) {
            return mobs.get();
        }
        return false;
    }

    private boolean isHostileMob(LivingEntity entity) {
        String entityName = entity.getType().getTranslationKey();
        return entityName != null && (
            entityName.contains("zombie") ||
            entityName.contains("skeleton") ||
            entityName.contains("creeper") ||
            entityName.contains("spider") ||
            entityName.contains("enderman") ||
            entityName.contains("witch")
        );
    }

    private boolean isHoldingWeapon() {
        if (mc.player.getMainHandStack().isEmpty()) return false;

        String itemName = mc.player.getMainHandStack().getItem().getTranslationKey();
        if (itemName == null) return false;

        return itemName.contains("sword") ||
               itemName.contains("axe") ||
               itemName.contains("trident") ||
               itemName.contains("bow") ||
               itemName.contains("crossbow") ||
               itemName.contains("spear");
    }

    @Override
    public void onDeactivate() {
        lastAttackTime = 0;
        consecutiveHits = 0;
        shouldMiss = false;
    }
}
