package com.nb.nbaddon;

public class MyScreen {
    public static void checkVersionOnServerJoin() {}
    public static void resetSessionCheck() {}
}
